function [ pesn ] = generate_pesn( inputNum, rNum )
pesn.inputNum = inputNum;
pesn.reservoirNum = rNum;
pesn.base = 'direct'; %'fft_base'; %
pesn.fun = @dethafun;

end

